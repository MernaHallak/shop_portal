export const queryKeys = {
  storeProducts: ["store", "products"] as const,
};
