import { apiClient } from "@/api/client";
import type {
  LoginRequest,
  LoginResponse,
} from "@/types/auth";

export async function login(
  credentials: LoginRequest,
): Promise<LoginResponse> {
  // اللي بيوصل للفرونت من route.ts عبر Axios هو فقط محتوى NextResponse.json(...) لان هاد هو الرد للفرونت
  const response = await apiClient.post<LoginResponse>(
    "/auth/login",
    credentials,
  );
  return response.data;
}

export async function logout(): Promise<void> {
  await apiClient.post("/auth/logout");
}
