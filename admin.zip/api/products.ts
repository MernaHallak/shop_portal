import {apiClient} from "@/api/client";
import type {ProductsResponse} from "@/types/product";

export async function getStoreProducts(): Promise<ProductsResponse> {
  const response = await apiClient.get<ProductsResponse>("/store/products");
  return response.data;
}
