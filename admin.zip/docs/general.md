## rerender state :
setState ما بتغيّر قيمة الـ state داخل نفس تنفيذ الفنكشن؛ هي بتطلب من React تحديثها. React يستنى الفنكشن تخلص، بعدين يعمل rerender، وبالـ render الجديد بتصير قيمة الـ state الجديدة متاحة للعرض.
يعني داخل نفس الفنكشن:
setEmail("new");
console.log(email); // القيمة القديمة

## الفرق بين router.replace و redirect:
router.replace
=> client-side navigation
=> بعد ما الصفحة اشتغلت بالمتصفح متل صفحة 
مثل صفحة تسجيل الدخول :
بعد ما صفحة login ظهرت بالمتصفح وكبس المستخدم إرسال ونجح login، تستخدم router.replace("/products") لأنه تنقّل من client بعد حدث submit.

redirect
=> server-side redirect
=> قبل عرض الصفحة غالبًا 
مثال: قبل ما تنعرض صفحة login، السيرفر يتحقق من الجلسة، وإذا المستخدم مسجل دخول يحوّله فورًا لـ /products.

-------------------------------------
## الفرق بين <img /> و <Image /> :

<img /> :وسم HTML عادي، يعرض الصورة مباشرة من أي رابط.

<Image /> : كومبوننت من Next.js، يعمل optimization للصورة مثل lazy loading، تغيير الحجم، وتحسين الأداء، لكن يحتاج إعدادات بال  next.config.ts للسماح بالدومين الخارجي الذي تأتي منه الصورة.

lazy loading يعني الصورة ما بتنحمّل فورًا، بتنحمّل بس لما تقرب تظهر على الشاشة.الفائدة: الصفحة تفتح أسرع وتستهلك نت أقل.

استخدمنا <img> لأن:  product.image_url جاي من الكلاودنري وممكن يكون من hosts مختلفة، و<Image /> قد يرفضها إذا الدومين غير مضاف في next.config.  
لو عندك دومين ثابت للصور، الأفضل تستخدمين next/image.  

في next.config.ts أو next.config.js ضيفي Cloudinary ضمن remotePatterns، لأن Next يطلب تحديد مصادر الصور الخارجية المسموحة لـ <Image />.

import type {NextConfig} from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "res.cloudinary.com", //host: يعني دومين/عنوان السيرفر/الخدمة اللي تستضيف الصورة
        pathname: "/YOUR_CLOUD_NAME/**", بدلو باسم cloud name تبعك من Cloudinary. البشوفا من https://res.cloudinary.com/your-cloud-name/image/upload/... الموجودة بال DevTools → Network → Img، وافتحي request الصورة وشوفي Request URL او بطبع ال  console.log(product.image_url); فبيطلع الرابط
      },
    ],
  },
};

export default nextConfig;

وبدل ال <img /> ب <Image
  src={product.image_url}
  alt={t("imageAlt", {name})}
  width={64}
  height={64} 
/>
بعد تعديل next.config لازم تعيدي تشغيل السيرفر: npm run dev 

