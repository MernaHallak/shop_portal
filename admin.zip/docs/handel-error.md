 ## خطوات الخطا:

External Backend
يرجع خطأ خام
↓ داخل route.ts

normalizeBackendError
ينظف ويرجع body موحّد:
{ message, code, errors }

route.ts يرجع HTTP response
↓
المتصفح يستقبله
المتصفح هو البيئة اللي فيها كود الفرونت شغال، وداخل هالبيئة Axios هو اللي أرسل الطلب وهو اللي يستلم نتيجة الطلب.
const response = await apiClient.post<LoginResponse>( هاد اكسيوس الفرونت
    "/auth/login",
    credentials,
  );
↓
Axios الفرونت يستلمه
↓
إذا status 2xx => يعطيك response
إذا status خارج 2xx => يرمي AxiosError:
error.response.status
error.response.data

Axios يرمي AxiosError
↓
login لا ترجع LoginResponse
↓
React Query يمسك الخطأ
↓
يحطه داخل property اسمها error //React Query يأخذ الشيء اللي انرمى من mutationFn ويحطه كما هو داخل property اسمها:error
المقصود mutationFn نفسها؛ يعني الدالة اللي بتنفيذ العملية مثل login(credentials)، وإذا جواتها Axios رمى خطأ، React Query بياخد هالخطأ ويحطه في error.
إذا ما في خطأ، mutationFn بترجع نتيجة login(credentials)، وReact Query بيحفظها داخل property اسمها:data  

↓ داخل component/hook
const { mutate, error, isError, isPending, reset } = useLogin(); //error  الخطأ اللي رماه Axios

normalizeApiError
normalizeApiError وظيفتها: تأخذ الخطأ التقني الجاي من Axios/React Query، وتحوّله لشكل ثابت وسهل للواجهة مثل { status, code, message, fieldErrors, translationKey } حتى نعرض رسالة مناسبة للمستخدم بدون ما نفك AxiosError بكل component بهذا الشكل 
if (axios.isAxiosError(error)) {
  const status = error.response?.status;
  const message = error.response?.data?.message;
  // افحصي network error
  // افحصي 401
  // افحصي 500
  // افحصي field errors
}
normalizeApiError يحوّل AxiosError إلى UI error:
{ status, code, message, fieldErrors, translationKey }

↓ UI

t(error.translationKey)
أو عرض fieldErrors.email

translationKey => رسالة عامة للمستخدم
fieldErrors.email/password => رسائل تحت الحقول

## بالمختصررر  خطوات الخطا:
route.ts رجع HTTP response بفشل
↓
Axios الفرونت استلم status 401/422/500
↓
Axios حوّله إلى AxiosError
↓
React Query حطه داخل error
ومنحطو بال normalizeApiError لنعرضو بالواجهة بشكل موحد وبسيط

---------------------------------
## لي عم اتحقق انو الخطا شكلو اكسيوس بال export function normalizeApiError:
كنت عم اتحقق انو الخطا شكلو اكسيوس لأن normalizeApiError(error) تستقبل error: unknown يعني دالة عامة ممكن تنادى بأي خطأ، وليس فقط خطأ جاي من Axios.
مثال عندك حاليًا:const normalizedError = normalizeApiError(error, "login"); هون غالبًا error هو AxiosError.
لان المسار محدد جدًا:
route.ts رجع HTTP response بفشل
↓
Axios الفرونت استلم status 401/422/500
↓
Axios حوّله إلى AxiosError
↓
React Query حطه داخل error

بس ممكن لاحقًا يصير في mutationFn هيك:

mutationFn: async (credentials) => {

  if (!credentials.email) {

    throw new Error("Missing email before request");

  }
  return login(credentials);

}
هون الخطأ صار قبل Axios يعني قبل ما يفوت على login ويعمل طلب اكسيوس، فمو AxiosError.

-----------------------------------------
## AxiosError نوعين مهمين:

AxiosError ومعه response
=> السيرفر ردّ HTTP response مثل 401/500
=> نقرأ: error.response.status و error.response.data

AxiosError بدون response
=> الطلب ما وصل أو ما رجع رد HTTP واضح
=> مثل network error / CORS / timeout يعني الطلب أخذ وقت أطول من الحد المسموح، فـ Axios أوقفه واعتبره فشل اتصال / server down 
=> ما في error.response.data أصلًا
فبقرا من الخصائص عامة على AxiosError نفسهم  error.code - error.message
أما error.response.data.code فهي code جاية من body تبع السيرفر لما يكون في HTTP response.

غياب response غالبًا يعني مشكلة اتصال networkError
إمّا الطلب ما وصل للباك أصلًا، أو وصل والباك رد بس الرد انحجب/انقطع قبل ما Axios يستلمه؛ المهم من جهة Axios: ما عنده response لذلك يعاملها networkError.
----------------------------
## فايدة ال optional chaining "?"
error.response?.status فالـ "?." يقول إذا response غير موجودة، لا تكملي لـ .status ورجّعي undefined.
undefined يعني: القيمة غير موجودة/لم يتم تحديدها.

data?.error  احميني إذا data غير موجودة ورجع undefined بدل ايرور ، وإذا error غير موجودة رجّع undefined عادي  لأن قراءة property غير موجودة من object موجود ما بتكسر  الكود اما اذا كان الاوبجيكت هو المو موجود ومو حاطة "؟" وقتا رح ينكسر الكود ويرجع ايرور

console.log(data.error); // undefined
console.log(data?.error); // undefined