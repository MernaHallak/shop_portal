"use client";

import {useState} from "react";
import {useTranslations} from "next-intl";

import {logout} from "@/api/auth";
import {LanguageSwitcher} from "@/components/language-switcher";
import {useRouter} from "@/i18n/navigation";

export function ProductsShell({children}: {children: React.ReactNode}) { //ProductsShell  الغلاف/الهيكل العام لصفحة المنتجات.
  // عملنا هاد الغلاف وستخدمنا children ليصير الغلاف reusable وأنظف.
  const t = useTranslations("Products");
  const common = useTranslations("Common");
  const router = useRouter();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  async function handleLogout() {
    setIsLoggingOut(true);
    try {
      await logout();
    } finally {
      router.replace("/login");
    }
  }

  return (
    <main className="dashboard-page">
      <header className="dashboard-header">
        <a className="brand" href="#main-content">
          <span className="brand-mark small" aria-hidden="true">S</span>
          {common("brand")}
        </a>
        <div className="header-actions">
          <LanguageSwitcher />
          <button
            className="logout-button"
            type="button"
            onClick={handleLogout}
            disabled={isLoggingOut}
          >
            {isLoggingOut ? common("loading") : common("logout")}
          </button>
        </div>
      </header>
      <div className="dashboard-content" id="main-content">
        <div className="page-heading">
          <p className="eyebrow">{t("eyebrow")}</p>
          <h1>{t("title")}</h1>
          <p>{t("description")}</p>
        </div>
        {children}
      </div>
    </main>
  );
}
