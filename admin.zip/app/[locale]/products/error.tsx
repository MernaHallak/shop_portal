"use client";

export default function ErrorPage({
  error,
  reset, //reset هي function من Next تعيد محاولة render  للمسار الحالي الذي ظهر فيه الخطأ من جديد
//   مثال :app/[locale]/products/error.tsx
// app/[locale]/products/page.tsx
// app/[locale]/products/[id]/page.tsx
// هون error.tsx تبع products يمسك أخطاء: /ar/products /ar/products/123
}: {
  error: Error;
  reset: () => void; //يعني دالة ما بتأخذ أي arguments و ما بترجع قيمة
}) {
  return (
    <main>
      <h1>حدث خطأ</h1>
      <p>تعذر التحقق من الجلسة حاليًا.</p>
      <button onClick={reset}>حاول مرة أخرى</button>
    </main>
  );
}