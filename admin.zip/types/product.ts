import type {SupportedLocale} from "@/i18n/routing";

export type {SupportedLocale};

export type LocalizedText = Partial<Record<SupportedLocale, string | null>>; //Partial يخلي كل اللغات اختيارية

export interface Pagination {
  page: number;
  limit: number;
  total: number;
  total_pages: number;
  has_next_page: boolean;
  has_previous_page: boolean;
}

export interface ProductSubcategory {
  id: string;
  category_id: string;
  slug: string;
  name: string;
  name_i18n?: LocalizedText | null;
  description: string | null;
  description_i18n?: LocalizedText | null;
}

export interface Product {
  id: string;
  name: string;
  name_ar: string | null;
  name_i18n?: LocalizedText | null;
  category: string;
  category_slug: string;
  subcategory: string | null;
  subcategory_ar: string | null;
  subcategory_i18n?: LocalizedText | null;
  price: number;
  description: string | null;
  description_ar: string | null;
  description_i18n?: LocalizedText | null;
  store_name: string;
  store_id: string;
  image_url: string | null;
  image_public_id: string | null;
  images: unknown[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
  subcategory_id: string | null;
  subcategory_slug: string | null;
  subcategory_details: ProductSubcategory | null;
}

export interface ProductsResponse {
  pagination: Pagination;
  products: Product[];
}
